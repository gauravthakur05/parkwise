# ParkWise — Parking Lot Management System

A college-project-friendly Parking Lot Management System with:
- **Core logic in simple, beginner-level C++** (arrays, classes, loops, if-else, file handling)
- **A clean HTML/CSS/JS dashboard frontend**
- **A tiny Node.js bridge** that connects the two (no logic lives in Node — it only relays calls)

---

## 1. How the frontend talks to the C++ code

This is the simplest architecture that keeps C++ beginner-friendly while still letting a browser use it:

```
 Browser (HTML/CSS/JS)
        |  fetch("/api/park", ...)
        v
 server.js  (plain Node.js, built-in "http" module only)
        |  spawns: ./backend/parking park PB10AB1234 Car
        v
 backend/parking  (compiled C++ program)
        |  reads/writes
        v
 data/parking_data.txt   (simple text file = our "database")
```

- The **C++ program is a normal console program**, just like the ones you write for
  college assignments. It takes a command (`park`, `exit`, `status`, `list`, `search`)
  as a command-line argument, does the work using a simple array of `Slot` objects,
  and prints one line of plain text as the result.
- **`server.js` does not contain any parking logic.** It only:
  1. Serves the `frontend/` folder so you can open the dashboard in a browser.
  2. When the browser calls an API like `/api/park`, it runs the compiled C++
     program with the right arguments (`execFile`), reads what it printed, and
     forwards that to the browser as JSON.
- Browsers cannot run `.cpp` or `.exe` files directly for security reasons, so this
  small Node relay is the simplest common workaround — it is **not** a replacement
  for the C++ logic, just a messenger between the browser and the C++ program.

---

## 2. Folder structure

```
ParkingLotSystem/
├── backend/
│   └── parking.cpp        # ALL parking logic (beginner-friendly C++)
├── data/
│   └── parking_data.txt   # auto-created text file used to store slot data
├── frontend/
│   ├── index.html         # dashboard page
│   ├── style.css          # styling
│   └── script.js          # calls the API with fetch()
├── server.js              # tiny Node.js bridge (no npm packages needed)
└── README.md
```

---

## 3. Requirements

- A C++ compiler: **g++** (comes with MinGW on Windows, or already installed on
  Mac/Linux). Check with `g++ --version`.
- **Node.js** (v14 or newer) — only used to run the bridge server, no `npm install`
  is required since `server.js` uses only built-in modules.

---

## 4. How to compile the C++ code

Open a terminal inside the `backend/` folder:

```bash
cd ParkingLotSystem/backend
g++ -o parking parking.cpp        # Mac/Linux
g++ -o parking.exe parking.cpp    # Windows
```

This creates an executable called `parking` (or `parking.exe`) in the `backend/`
folder. You can test it directly from the terminal if you like:

```bash
./parking status
./parking park PB10AB1234 Car
./parking list
./parking exit PB10AB1234
```

---

## 5. How to run the full project

1. **Compile the C++ code first** (step 4 above) — do this every time you change
   `parking.cpp`.
2. From the **project root folder** (`ParkingLotSystem/`), start the bridge server:
   ```bash
   node server.js
   ```
   You should see:
   ```
   Parking Lot Management System is running!
   Open this in your browser: http://localhost:3000
   ```
3. **Open the frontend**: go to `http://localhost:3000` in your browser. The
   dashboard is served automatically — you don't need to open `index.html` directly.

---

## 6. Using the dashboard

- **Vehicle Entry** — enter a vehicle number and type, click "Park Vehicle". The
  C++ program finds the first free slot and records the entry time.
- **Vehicle Exit** — enter the vehicle number, click "Exit & Calculate Fee". The
  C++ program calculates the fee based on how long the vehicle was parked
  (₹10/hr Bike, ₹20/hr Car, ₹40/hr Truck, minimum 1 hour) and frees the slot.
- **Search Vehicle** — quickly find which bay a vehicle is parked in.
- **Currently Parked table + slot map** — shows live data straight from
  `data/parking_data.txt`, refreshed automatically after every action (or
  manually with the "Refresh" button).

---

## 7. Notes for your college viva

- The parking lot is a fixed-size **array of 10 slots** (`TOTAL_SLOTS = 10` in
  `parking.cpp`) — change this constant to resize the lot.
- Persistence is done with plain `ifstream` / `ofstream` file handling — no
  database is used.
- Searching for a free slot / a vehicle is a simple **linear search** (`for` loop),
  which is exactly the kind of basic DSA concept expected at this level.
- Fee calculation uses simple `if-else` rules and integer arithmetic, rounding
  up to the next hour.
